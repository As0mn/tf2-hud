#base "huditemeffectmeter_demoman.res"

"Resource/UI/HudItemEffectMeter_Killstreak.res"
{
	HudItemEffectMeter
	{
		"xpos"			"94"	[$WIN32]
		"ypos"			"r52"	[$WIN32]
		"xpos_minmode"	"r215"	[$WIN32]
	}
}
