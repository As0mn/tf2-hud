ViviHUD

Copyright (c) 2025 LlamaGR1, llamaclapped, llamaras, sparkless

This work is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 4.0 Unported License (CC BY-NC-ND 4.0)

This WiP/MOD and its components may not be redistributed, modified and distributed on GameBanana, TF2 HUDs, GitHub or any other site/platform